# Project

Group Name:DMSR\
Student Names: Divya Malyala (G01390473), Sai Ram Vangala (G01373045), Vinitha Puligorla (G01397891)

# Example

Lets consider the below DNN example

![img_8.png](img_8.png)


Lets assume that the safe ouput for this DNN is f<20

Using the Naive approach is not preferable because it would not provide the tight bounds that we would need, to evaluate safety property

# Naive Interval Propagation

Input layers nodes = x,y
Hidden layers nodes = A,B
Output layers node = f

Step1: Hidden layer 1 evaluation
```commandline
lb = lower bound
ub = upper bound
```
<br>
Lower bound and upper bounds for each node are evaluated by multiplying associated weights, and corresponding lower or upper bounds of the preceeding nodes and then summing them up <br>
If we are evaluating lower bound for a node, and if there is a negative weight associated with the preceding node, then their upper bound is multiplied with weight instead of lower bound and Vice-Versa

![img_9.png](img_9.png)

Here we get output interval as [0,22], which is a Safety violation

# Symbolic Interval Analysis

In this approach, instead of the intervals, input nodes are considered as variables, and formula for the output nodes are evaluated by considering the weights <br>
Input interval bound values are substituted to the formula generated for the output nodes to evaluate bounds of output nodes

![img_10.png](img_10.png)

In this case we get output interval as [6,16]. It was better than naive approach but does over approximation. So, we go with bisection of intervals

# Iterative Interval Refinement using Bisection

Iterative Interval Refinement has same process as of Naive interval propagation approach in addition with bisection<br>
An input interval is bisected into 2 parts and then for each part the output intervals are evaluated. The final output interval is calculated by performing Union operation on all the final output intervals evaluated for each part from bisection<br>
We choose the interval to bisect based on smear function, which is dependent on input range width and absolute gradient. <br>
# Example 1
Lets bisect node y as it has wider range among the input layer nodes<br>
![img_16.png](img_16.png)
<br>
1st iteration for the hidden layer nodes
![img_17.png](img_17.png)
<br>
2nd iteration for the output layer node
![img_18.png](img_18.png)
Output intervals
```commandline
[2,16] U [6,20] = [2,20]
``` 
<br>
This is safe interval <br>
Lets discuss another scenario with an example with iterative bisection and refinement

# Example 2

Lets bisect node y as it has wider range among the input layer nodes<br>
Bisecting the interval for node 'y'. [1,3] and [3,5].<br>

Below example shows how bisection and interval evalution are done<br>
Intervals for Nodes A,B,f considering each bisected intervals are calculated individually<br><br>

1st Iteration for the hidden layer nodes<br>
![img_11.png](img_11.png)<br>

2nd Iteration for the output layer nodes<br>
![img_12.png](img_12.png)<br>

Here we still did not get safety as the output interval resulted in [-4,21] <br>

# More bisection of intervals

1st iteration for hidden layer nodes <br>
![img_13.png](img_13.png)<br>
![img_15.png](img_15.png)<br>
2nd iteration for output layer nodes <br>
![img_14.png](img_14.png)<br>

If we perform union for the f intervals we get
```commandline
[5,18] U [3,17] U [1,15] U [-1,13] = [-1,18]
```
Which is safe. Hence we get safe intervals with ReluVal by implementing bisection
